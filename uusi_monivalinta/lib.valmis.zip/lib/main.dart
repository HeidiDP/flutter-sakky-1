import 'package:flutter/material.dart';
import 'package:uusi_monivalinta/quiz.dart';

void main() {
  runApp(const Quiz());
}

